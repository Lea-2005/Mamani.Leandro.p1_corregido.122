package parcial122;

public enum TipoAgua {
    DULCE,
    SALADA
}
