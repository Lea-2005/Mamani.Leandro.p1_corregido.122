package parcial122;

public interface Nadable {

    void nadar();
}
