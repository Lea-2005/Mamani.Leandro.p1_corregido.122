package parcial122;

public class MamiferoMarino extends Animal implements Nadable, Alimentable {

    private int frecuenciaRespiracion;

    public MamiferoMarino(int frecuenciaRespiracion, String nombre, String habitat, TipoAgua tipoAgua) {
        super(nombre, habitat, tipoAgua);
        validarFrecuencia(frecuenciaRespiracion);
        this.frecuenciaRespiracion = frecuenciaRespiracion;
    }

    @Override
    String detallarCaracteristica() {
        return frecuenciaRespiracion + " segundos";
    }
    
    private void validarFrecuencia(int frecuencia) {
        if (frecuencia < 0) {
            throw new IllegalArgumentException("Frecuencia invalida");
        }
    }
    
    @Override
    public void nadar() {
        System.out.println(getNombre() + " esta nadando por su habitat.");
    }
    
    @Override
    public void alimentar() {
        System.out.println(getNombre() + " esta buscando su comida.");
    }    
}
