package parcial122;

public interface Alimentable {

    void alimentar();
}
