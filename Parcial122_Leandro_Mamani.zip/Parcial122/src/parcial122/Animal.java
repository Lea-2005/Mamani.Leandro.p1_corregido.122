package parcial122;

import java.util.List;
import java.util.Objects;

public abstract class Animal{

    private String nombre;
    private String habitat;
    private TipoAgua tipoAgua;

    public Animal(String nombre, String habitat, TipoAgua tipoAgua) {
        this.nombre = nombre;
        this.habitat = habitat;
        this.tipoAgua = tipoAgua;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (this == null || !(o instanceof Animal e)) {
            return false;
        }
        return nombre.equals(e.nombre) && habitat.equals(e.habitat);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, habitat);
    }

    abstract String detallarCaracteristica();

    public static String toHeaderRow() {
        return "|   Nombre    |   Habitat    | Tipo agua |  Caracteristica |\n";
    }

    public String toTableRow() {
        return "| %-12s|  %-12s| %-10s| %-16s|\n".formatted(nombre, habitat, tipoAgua, detallarCaracteristica());
    }

    public static String toStringTable(List<Animal> lista) {
        StringBuilder sb = new StringBuilder();
        int ancho = toHeaderRow().length();

        sb.append(Utils.separadorHorizontal(ancho));
        sb.append(toHeaderRow());
        sb.append(Utils.separadorHorizontal(ancho));
        for (Animal a : lista) {
            sb.append(a.toTableRow());
        }
        sb.append(Utils.separadorHorizontal(ancho));
        return sb.toString();
    }

    public boolean esTipo(TipoAgua tipo) {
        return this.tipoAgua == tipo;
    }

    public boolean esNombre(String nombre) {
        return this.nombre.equals(nombre);
    }

    public String getNombre() {
        return nombre;
    }

    public TipoAgua getTipoAgua() {
        return tipoAgua;
    }

    @Override
    public String toString() {
        return "Animal{" + "nombre=" + nombre + ", habitat=" + habitat + ", tipoAgua=" + tipoAgua + '}';
    }
}
