package parcial122;

public class Pez extends Animal implements Nadable {

    private double longitudMaxima ;

    public Pez(double longitudMaxima, String nombre, String habitat, TipoAgua tipoAgua) {
        super(nombre, habitat, tipoAgua);
        validarLongitud(longitudMaxima);
        this.longitudMaxima = longitudMaxima;
    }

    @Override
    String detallarCaracteristica() {
        return longitudMaxima + " cm";
    }

    @Override
    public void nadar() {
        System.out.println(getNombre() + " esta nadando por el agua.");
    }

    private void validarLongitud(double longitud) {
        if (longitud < 0) {
            throw new IllegalArgumentException("Longitud invalida");
        }    
    }      
}
