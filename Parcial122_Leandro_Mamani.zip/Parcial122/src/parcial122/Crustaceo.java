package parcial122;

public class Crustaceo extends Animal implements Alimentable {

    private int numeroPatas;

    public Crustaceo(int numeroPatas, String nombre, String habitat, TipoAgua tipoAgua) {
        super(nombre, habitat, tipoAgua);
        validarNumero(numeroPatas);
        this.numeroPatas = numeroPatas;
    }

    @Override
    String detallarCaracteristica() {
        return numeroPatas + " n* patas";
    }

    private void validarNumero(int numeroPatas) {
        if (numeroPatas < 0) {
            throw new IllegalArgumentException("Numero de patsa invalido.");
        }
    }

    @Override
    public void alimentar() {
        System.out.println(getNombre() + " esta buscando su comida.");
    }
}
