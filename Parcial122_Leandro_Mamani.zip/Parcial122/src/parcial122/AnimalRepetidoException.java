package parcial122;

public class AnimalRepetidoException extends RuntimeException {

    private static final String MESSAGE = "Animal repetido.";

    public AnimalRepetidoException() {
        this(MESSAGE);
    }

    public AnimalRepetidoException(String mensaje) {
        super(mensaje);
    }
}
