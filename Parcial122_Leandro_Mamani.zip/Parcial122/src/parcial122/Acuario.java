package parcial122;

import java.util.ArrayList;
import java.util.List;

public class Acuario {

    private List<Animal> animales;

    public Acuario() {
        animales = new ArrayList<>();
    }

    private void validarAnimal(Animal animal) {
        if (animal == null) {
            throw new IllegalArgumentException("Animal nulo");
        }
        if (animales.contains(animal)) {
            throw new AnimalRepetidoException();
        }
    }

    public void agregarAnimal(Animal animal) {
        validarAnimal(animal);
        animales.add(animal);
    }

    public void mostrarAnimales(boolean titulo) {
        if (animales.isEmpty()) {
            throw new IllegalArgumentException("No hay animales registrados");
        }
        if (titulo) {
            System.out.println("===== Acuario =====");
        }
        System.out.println(Animal.toStringTable(animales));
    }

    public void nadar() {
        System.out.println("== Moviendo especies ==");
        for (Animal a : animales) {
            if (a instanceof Nadable) {
                ((Nadable) a).nadar();
            } else {
                System.out.println(a.getNombre() + " no puede nadar.");
            }
        }
    }

    public void buscarAlimento() {
        System.out.println("== Alimentando especies ==");
        for (Animal a : animales) {
            if (a instanceof Alimentable) {
                ((Alimentable) a).alimentar();
            } else {
                System.out.println(a.getNombre() + " no busca comida.");
            }
        }
    }

    public void filtrarPorTipoAgua(TipoAgua tipo) {
        ArrayList<Animal> toReturn = new ArrayList<>();
        for (Animal a : animales) {
            if (a.getTipoAgua() == tipo) {
                toReturn.add(a);
            }
        }
        if (toReturn.isEmpty()) {
            throw new IllegalArgumentException("No hay animales de agua: " + tipo);
        } else {
            System.out.println(Animal.toStringTable(toReturn));
        }
    }

    public void mostrarAnimalesPorTipo(String tipoAnimal) {
        ArrayList<Animal> toReturn = new ArrayList<>();
        for (Animal a : animales) {
            if (a.getClass().getSimpleName().equalsIgnoreCase(tipoAnimal)) {
                toReturn.add(a);
            }
        }
        if (toReturn.isEmpty()) {
            throw new IllegalArgumentException("No hay animales de ese tipo");
        } else {
            System.out.println(Animal.toStringTable(toReturn));
        }
    }
}
