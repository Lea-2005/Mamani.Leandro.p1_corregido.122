package parcial122;

public class Utils {

    public static String separadorHorizontal(int largo) {
        return separadorHorizontal(largo, '=');
    }

    public static String separadorHorizontal(int largo, char caracter) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < largo; i++) {
            sb.append(caracter);
        }
        sb.append("\n");
        return sb.toString();
    }
}
