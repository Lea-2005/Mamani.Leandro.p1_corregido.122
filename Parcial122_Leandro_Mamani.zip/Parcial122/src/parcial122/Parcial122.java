package parcial122;

public class Parcial122 {

    public static void main(String[] args) {
        Acuario acuario = new Acuario();

        acuario.agregarAnimal(new Pez(10, "Payaso", "Lado 1", TipoAgua.SALADA));
        acuario.agregarAnimal(new Pez(7, "Tilapia", "Lado 3", TipoAgua.DULCE));       
        acuario.agregarAnimal(new Crustaceo(10, "Cangrejo", "Lado 3", TipoAgua.DULCE));
        acuario.agregarAnimal(new Crustaceo(11, "Langosta", "Lado 2", TipoAgua.SALADA));
        acuario.agregarAnimal(new MamiferoMarino(2, "Delfin", "Lado 1", TipoAgua.SALADA));
        acuario.agregarAnimal(new MamiferoMarino(2, "Foca", "Lado 2", TipoAgua.SALADA));

        acuario.mostrarAnimales(true);

        acuario.nadar();
        acuario.buscarAlimento();
        acuario.filtrarPorTipoAgua(TipoAgua.DULCE);
        acuario.mostrarAnimalesPorTipo("MamiferoMarino");
    }

}